import {data} from '../pages/Data/Data';
export const  bookData = [
    {
        img: data.CardImg1,
        bookName: 'Steve Jobs',
        bookAvtori: 'Walter Isaacson',
        Janri:'Biznes, yuksalish',
        bookHudud:'Andijon',
        day:'kecha'
    },
    {
        img: data.CardImg2,
        bookName: 'Rework',
        bookAvtori: 'Jason Fried',
        Janri:'Biznes, yuksalish',
        bookHudud:'Namangan',
        day:'kecha'
    },
    {
        img:data.CardImg3,
        bookName: 'Billion dollar whale',
        bookAvtori: 'Bradley Hope',
        Janri:'Biznes, yuksalish',
        bookHudud:'Tashkent',
        day:'kecha'
    },
    {
        img: data.CardImg4,
        bookName: 'Tell me to stop',
        bookAvtori: 'Walter Isaacson',
        Janri:'Biznes, yuksalish',
        bookHudud:'Qarshi',
        day:'kecha'
    },
     {
        img: data.CardImg1,
        bookName: 'Steve Jobs',
        bookAvtori: 'Walter Isaacson',
        Janri:'Biznes, yuksalish',
        bookHudud:'Andijon',
        day:'kecha'
    },
    {
        img: data.CardImg2,
        bookName: 'Rework',
        bookAvtori: 'Jason Fried',
        Janri:'Biznes, yuksalish',
        bookHudud:'Namangan',
        day:'kecha'
    },
    {
        img:data.CardImg3,
        bookName: 'Billion dollar whale',
        bookAvtori: 'Bradley Hope',
        Janri:'Biznes, yuksalish',
        bookHudud:'Tashkent',
        day:'kecha'
    },
    {
        img: data.CardImg4,
        bookName: 'Tell me to stop',
        bookAvtori: 'Walter Isaacson',
        Janri:'Biznes, yuksalish',
        bookHudud:'Qarshi',
        day:'kecha'
    },


];