import React from 'react';
import './Card.css'
const Card = () => {
  return(
      <div className="card">
      </div>
  )
};

export default Card;
