import Img from '../../images/brend.png';
import CardImg1 from '../../images/card-img1.png';
import CardImg2 from '../../images/card-img2.png';
import CardImg3 from '../../images/card-img3.png';
import CardImg4 from '../../images/card-img4.png';
import Camera from '../../images/camera.png';
import Avatar from '../../images/avatar.png';
export const data = {
  brandImg: Img ,
  CardImg1: CardImg1,
  CardImg2: CardImg2,
  CardImg3: CardImg3,
  CardImg4:CardImg4,
  Camera: Camera,
  Avatar:Avatar
};